$(document).ready(function(){

	var tabNum = 1;
    var triTime = 0;
    var tabTrigger = setInterval(tabTimer, 800);
    function tabTimer(){
        triTime+=1;
        if(triTime == 60){
            triTime=1;
            if(tabNum == 3){
                tabNum = 0;
            }
            $('.dashBoardTab02 li').eq(tabNum).find('a').trigger('click');
        }
    }

    $('.dashBoardTab02 li a').on('click',function(){
        $(this).addClass('active').parent().siblings().find('a').removeClass('active');
        $('.left .tabCon').hide();
        $('.left .tab'+($(this).parent().index()+1)).show();
        tabNum = $(this).parent().index()+1;
        triTime = 0;
    })
})
