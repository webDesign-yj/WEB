$(function() {

  /* header */
  var header = {
    gnb_menu: $('.header .gnb_menu'),
    gnb_func: function() {
      $('.header').on('mouseleave', function() {
        $('.header .gnb > ul > li').removeClass('on');
        $('.header').removeClass('active');
        $(this).removeClass('on');
      });
      this.gnb_menu.parent().on('mouseenter', function() {
        $('.header .gnb > ul > li').removeClass('on');
        $('.header').addClass('active');
        $(this).addClass('on');
      });
      this.gnb_menu.on('focus', function() {
        $('.header .gnb > ul > li').removeClass('on');
        $('.header').addClass('active');
        $(this).parent().addClass('on');
      });
    },
    init: function() {
      this.gnb_func();
    }
  }

  /* main */
  var main = {
    header_height: $('.header').height(),
    gnb_white_flag: 1,
    gnb_menu: $('.header .gnb_menu'),
    gnb_func: function() {
      $('.header').on('mouseleave', function() {
        $('.header .gnb > ul > li').removeClass('on');
        $('.header').removeClass('active');
        $(this).removeClass('on');
      });
      this.gnb_menu.parent().on('mouseenter', function() {
        $('.header .gnb > ul > li').removeClass('on');
        $('.header').addClass('active');
        $(this).addClass('on');
      });
      this.gnb_menu.on('focus', function() {
        $('.header .gnb > ul > li').removeClass('on');
        $('.header').addClass('active');
        $(this).parent().addClass('on');
      });
    },
  };

  if($('.main').length){
    main.init();
  } else {
    header.init();
  }

});
